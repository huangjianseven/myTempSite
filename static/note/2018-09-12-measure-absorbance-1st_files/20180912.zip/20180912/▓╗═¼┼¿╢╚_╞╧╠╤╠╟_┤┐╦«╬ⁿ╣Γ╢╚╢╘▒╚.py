from matplotlib.pyplot import *
import numpy as np

RAW0=np.loadtxt(open("i_0.txt","rb"),delimiter=" ",dtype='float',skiprows=0)
RAW_water=np.loadtxt(open("pure_water.txt","rb"),delimiter=" ",dtype='float',skiprows=0)
RAW_G1=np.loadtxt(open("Glucose_1.txt","rb"),delimiter=" ",dtype='float',skiprows=0)
RAW_G2=np.loadtxt(open("Glucose_2.txt","rb"),delimiter=" ",dtype='float',skiprows=0)
RAW_G3=np.loadtxt(open("Glucose_3.txt","rb"),delimiter=" ",dtype='float',skiprows=0)
RAW_G4=np.loadtxt(open("Glucose_4.txt","rb"),delimiter=" ",dtype='float',skiprows=0)

Wavelength = RAW0[:,0]
I_0 = RAW0[:,1] # Intensity of reference
I_water = RAW_water[:,1] # Intensity of pure water
I_G1 = RAW_G1[:,1] # Intensity of glucose 0.5mol
I_G2 = RAW_G2[:,1]
I_G3 = RAW_G3[:,1]
I_G4 = RAW_G4[:,1]

transmission_rate_water = I_0/I_water
absorbance_water = np.log10(transmission_rate_water)

transmission_rate_glucose_1 = I_0/I_G1
absorbance_g1 = np.log10(transmission_rate_glucose_1)

transmission_rate_glucose_2 = I_0/I_G2
absorbance3_g2 = np.log10(transmission_rate_glucose_2)

transmission_rate_glucose_3 = I_0/I_G3
absorbance_g3 = np.log10(transmission_rate_glucose_3)

transmission_rate_glucose_4 = I_0/I_G4
absorbance_g4 = np.log10(transmission_rate_glucose_4)

plot(Wavelength,absorbance_water,label='Pure Water')
plot(Wavelength,absorbance_g1,label='Glucose 0.5mol')
plot(Wavelength,absorbance3_g2,label='Glucose 1.0mol')
plot(Wavelength,absorbance_g3,label='Glucose 2.0mol')
plot(Wavelength,absorbance_g4,label='Glucose 3.0mol undissolved')

xlabel('Wavelength(nm)')
ylabel('Absorbance(a.u.)')

grid(linestyle='--', linewidth=0.5)
legend(loc='lower right')
show()

#savefig('Figure1.png',dpi=300, format='png')