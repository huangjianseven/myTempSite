from matplotlib.pyplot import *
import numpy as np

RAW1=np.loadtxt(open("i_0.txt","rb"),delimiter=" ",dtype='float',skiprows=0)
RAW2=np.loadtxt(open("i_1.txt","rb"),delimiter=" ",dtype='float',skiprows=0)
RAW3=np.loadtxt(open("i_2.txt","rb"),delimiter=" ",dtype='float',skiprows=0)
RAW4=np.loadtxt(open("i_3.txt","rb"),delimiter=" ",dtype='float',skiprows=0)

Wavelength = RAW1[:,0]
I_0 = RAW1[:,1]
I_1 = RAW2[:,1]
I_2 = RAW3[:,1]
I_3 = RAW4[:,1]

transmission_rate_water = I_0/I_1
absorbance1 = np.log10(transmission_rate_water)

transmission_rate_ethanol = I_0/I_2
absorbance2 = np.log10(transmission_rate_ethanol)

transmission_rate_glucose = I_0/I_3
absorbance3 = np.log10(transmission_rate_glucose)

plot(Wavelength,absorbance1,label='Pure Water')
plot(Wavelength,absorbance2,label='Ethanol')
plot(Wavelength,absorbance3,label='Glucose')

xlabel('Wavelength(nm)')
ylabel('Absorbance(a.u.)')

grid(linestyle='--', linewidth=0.5)
legend(loc='upper left')
show()

#savefig('Figure1.png',dpi=300, format='png')