from matplotlib.pyplot import *
import numpy as np


RAW=np.loadtxt(open("20180920.csv","rb"),delimiter=",",dtype='float',skiprows=0)
noise=np.loadtxt(open("noise_50_cal_v2.txt","rb"),delimiter=" ",dtype='float',skiprows=0)

baseline = 0

Wavelength = RAW[:,0]
I_0 = RAW[:,1]
I_1 = RAW[:,2]

transmission_rate = I_1/I_0

plot(Wavelength,I_0,label='$I_0$')
plot(Wavelength,I_1,label='$I_1$($H_2O$)')
plot(noise[:,0],noise[:,1],label='Dark Noise')

xlabel('Wavelength(nm)')

ylabel('Intensity(a.u.)')
title(r'Raw of Halogen & $H_2O$ & Dark Noise' )

grid()
legend(loc='upper right')
show()