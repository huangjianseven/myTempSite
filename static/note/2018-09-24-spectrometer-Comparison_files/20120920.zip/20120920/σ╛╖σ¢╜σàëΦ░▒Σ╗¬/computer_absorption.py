from matplotlib.pyplot import *
import numpy as np

RAW1=np.loadtxt(open("i_0.PRN","rb"),delimiter=" ",dtype='float',skiprows=0)
RAW2=np.loadtxt(open("i_1.PRN","rb"),delimiter=" ",dtype='float',skiprows=0)

Wavelength = RAW1[268:1040,0]*1000
I_0 = RAW1[268:1040,1]
I_1 = RAW2[268:1040,1]

transmission_rate = I_0/I_1
absorbance = np.log10(transmission_rate)

plot(Wavelength,absorbance,label='Pure Water')

xlabel('Wavelength(nm)')
ylabel('Absorbance(a.u.)')

grid()
legend(loc='left')
show()